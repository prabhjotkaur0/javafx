package com.example.video_game_analytics;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.chart.PieChart;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class PieChartController {

    @FXML
    private PieChart pieChart;

    private final DatabaseConnector databaseConnector = new DatabaseConnector();

    public void initialize() {
        populatePieChart();
    }

    private void populatePieChart() {
        ObservableList<PieChart.Data> pieChartData = FXCollections.observableArrayList();

        try (Connection connection = databaseConnector.connect()) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT Studio, SUM(Global_Sales) AS TotalSales FROM moviesales GROUP BY Studio");

            while (resultSet.next()) {
                String studio = resultSet.getString("Studio");
                double totalSales = resultSet.getDouble("TotalSales");
                pieChartData.add(new PieChart.Data(studio, totalSales));
            }

            pieChart.setData(pieChartData);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
