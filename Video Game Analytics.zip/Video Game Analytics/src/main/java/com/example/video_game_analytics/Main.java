package com.example.video_game_analytics;

import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main extends Application {

    // Database connection parameters
    private static final String DB_URL = "jdbc:mysql://localhost:3306/movie_sales_db";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "1234";

    // JavaFX components
    private PieChart pieChart;
    private TableView<Movie> tableView;
    private Button switchButton;

    @Override
    public void start(Stage primaryStage) {
        // Initialize JavaFX components
        pieChart = new PieChart();
        tableView = new TableView<>();
        switchButton = new Button("Switch to TableView");

        // Event handler for the switch button
        switchButton.setOnAction(event -> {
            // Check if TableView is empty, if so, fetch data
            if (tableView.getItems().isEmpty()) {
                fetchTableData();
            }
            // Check the current root of the scene and switch between PieChart and TableView
            if (primaryStage.getScene().getRoot() instanceof VBox) {
                VBox root = new VBox(tableView, switchButton);
                Scene scene = new Scene(root, 800, 600);
                primaryStage.setScene(scene);
                switchButton.setText("Switch to PieChart");
            } else {
                VBox root = new VBox(pieChart, switchButton);
                Scene scene = new Scene(root, 800, 600);
                primaryStage.setScene(scene);
                switchButton.setText("Switch to TableView");
            }
        });

        // Fetch PieChart data initially
        fetchPieChartData();

        // Set up initial scene with PieChart
        VBox root = new VBox(pieChart, switchButton);
        Scene scene = new Scene(root, 800, 600);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Movie Sales Data");
        primaryStage.show();
    }

    // Method to fetch data for PieChart
    private void fetchPieChartData() {
        pieChart.getData().clear(); // Clear existing data
        pieChart.setTitle("Movie Sales By Studio"); // Set title

        // Connect to the database and fetch data
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT Studio, SUM(Global_Sales) AS TotalSales FROM moviesales GROUP BY Studio");

            // Process each row in the result set
            while (resultSet.next()) {
                String studio = resultSet.getString("Studio");
                double totalSales = resultSet.getDouble("TotalSales");
                pieChart.getData().add(new PieChart.Data(studio, totalSales)); // Add data to PieChart
            }
        } catch (SQLException e) {
            e.printStackTrace(); // Handle any SQL exceptions
        }
    }

    // Method to fetch data for TableView
    private void fetchTableData() {
        ObservableList<Movie> data = FXCollections.observableArrayList(); // Create observable list to hold data

        // Connect to the database and fetch data
        try (Connection connection = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD)) {
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT * FROM moviesales");

            // Process each row in the result set
            while (resultSet.next()) {
                Movie movie = new Movie(
                        resultSet.getString("Title"),
                        resultSet.getString("Director"),
                        resultSet.getInt("Release_Year"),
                        resultSet.getString("Genre"),
                        resultSet.getString("Studio"),
                        resultSet.getDouble("Global_Sales")
                );
                data.add(movie); // Add Movie object to the data list
            }

            tableView.setItems(data); // Set data to TableView

            // Define columns for TableView
            TableColumn<Movie, String> titleColumn = new TableColumn<>("Title");
            titleColumn.setCellValueFactory(cellData -> cellData.getValue().titleProperty());

            // Similar setup for other columns

            tableView.getColumns().addAll(titleColumn, directorColumn, releaseYearColumn, genreColumn, studioColumn, globalSalesColumn);

        } catch (SQLException e) {
            e.printStackTrace(); // Handle any SQL exceptions
        }
    }

    // Main method to launch the application
    public static void main(String[] args) {
        launch(args);
    }
}
