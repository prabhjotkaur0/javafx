package com.example.video_game_analytics;

import javafx.beans.binding.BooleanExpression;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.DoubleProperty;
import javafx.beans.value.ObservableValue;

public class Movie {
    private final StringProperty title;
    private final StringProperty director;
    private final IntegerProperty releaseYear;
    private final StringProperty genre;
    private final StringProperty studio;
    private final DoubleProperty globalSales;

    public Movie(String title, String director, int releaseYear, String genre, String studio, double globalSales) {
        this.title = new SimpleStringProperty(title);
        this.director = new SimpleStringProperty(director);
        this.releaseYear = new SimpleIntegerProperty(releaseYear);
        this.genre = new SimpleStringProperty(genre);
        this.studio = new SimpleStringProperty(studio);
        this.globalSales = new SimpleDoubleProperty(globalSales);
    }

    // Getters for JavaFX properties
    public StringProperty titleProperty() {
        return title;
    }

    public StringProperty directorProperty() {
        return director;
    }

    public IntegerProperty releaseYearProperty() {
        return releaseYear;
    }

    public StringProperty genreProperty() {
        return genre;
    }

    public StringProperty studioProperty() {
        return studio;
    }

    public DoubleProperty globalSalesProperty() {
        return globalSales;
    }

    // Getters for regular attributes
    public String getTitle() {
        return title.get();
    }

    public String getDirector() {
        return director.get();
    }

    public int getReleaseYear() {
        return releaseYear.get();
    }

    public String getGenre() {
        return genre.get();
    }

    public String getStudio() {
        return studio.get();
    }

    public double getGlobalSales() {
        return globalSales.get();
    }
}
