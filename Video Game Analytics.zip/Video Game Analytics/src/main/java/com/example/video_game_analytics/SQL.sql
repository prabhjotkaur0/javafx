CREATE DATABASE IF NOT EXISTS movie_sales_db;

USE movie_sales_db;

CREATE TABLE moviesales (
    Movie_ID INT AUTO_INCREMENT PRIMARY KEY,
    Title VARCHAR(255) NOT NULL,
    Director VARCHAR(255),
    Genre VARCHAR(255),
    Release_Year INT,
    Studio VARCHAR(255),
    Global_Sales DECIMAL(10, 2)
);
INSERT INTO moviesales (Title, Director, Genre, Release_Year, Studio, Global_Sales) VALUES
("Movie 1", "Director 1", "Action", 2005, "Studio A", 100000.00),
("Movie 2", "Director 2", "Comedy", 2010, "Studio B", 150000.00),
("Movie 3", "Director 3", "Drama", 2015, "Studio C", 200000.00),
("Movie 4", "Director 4", "Thriller", 2020, "Studio D", 250000.00),
("Movie 5", "Director 5", "Action", 2018, "Studio A", 300000.00);